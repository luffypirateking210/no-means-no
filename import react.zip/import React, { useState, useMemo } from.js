import React, { useState, useMemo } from 'react';
import { 
  BarChart3, 
  Settings, 
  MapPin, 
  LayoutDashboard, 
  Target, 
  Wallet, 
  TrendingUp, 
  Search,
  ChevronDown,
  Bell,
  LogOut,
  Info
} from 'lucide-react';

// --- Mock Data ---
const INITIAL_KEYWORDS = [
  { id: 1, keyword: 'buy running shoes', volume: 12500, suggestedBid: 15, maxCpc: 0 },
  { id: 2, keyword: 'best sneakers 2024', volume: 8400, suggestedBid: 42, maxCpc: 0 },
  { id: 3, keyword: 'affordable gym wear', volume: 5200, suggestedBid: 28, maxCpc: 0 },
  { id: 4, keyword: 'marathon trainer sale', volume: 3100, suggestedBid: 55, maxCpc: 0 },
  { id: 5, keyword: 'lightweight walking shoes', volume: 15000, suggestedBid: 12, maxCpc: 0 },
  { id: 6, keyword: 'crossfit gear online', volume: 2200, suggestedBid: 35, maxCpc: 0 },
];

const App = () => {
  // --- State Management ---
  const [activeTab, setActiveTab] = useState('Campaigns');
  const [location, setLocation] = useState('India');
  const [budget, setBudget] = useState(50000);
  const [keywords, setKeywords] = useState(INITIAL_KEYWORDS);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currencySymbol = location === 'India' ? '₹' : '$';

  // --- Calculations ---
  const handleCpcChange = (id, value) => {
    const updated = keywords.map(kw => {
      if (kw.id === id) {
        const val = parseFloat(value) || 0;
        return { ...kw, maxCpc: val };
      }
      return kw;
    });
    setKeywords(updated);
  };

  const calculateEstClicks = (kw) => {
    if (kw.maxCpc <= 0) return 0;
    // Simple logic: higher max CPC relative to suggested bid increases CTR efficiency
    const ratio = Math.min(kw.maxCpc / kw.suggestedBid, 1.5);
    const clicks = Math.round((kw.volume * 0.05) * ratio);
    return clicks.toLocaleString();
  };

  const handleSubmit = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      alert('Campaign submitted successfully! Data is now being processed by the simulation engine.');
    }, 1500);
  };

  // --- Navigation Items ---
  const navItems = [
    { name: 'Campaigns', icon: Target },
    { name: 'Analytics', icon: BarChart3 },
    { name: 'Budgeting', icon: Wallet },
    { name: 'Settings', icon: Settings },
  ];

  return (
    <div className="flex h-screen bg-gray-50 font-sans text-slate-900">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-6">
          <div className="flex items-center gap-2 text-blue-600 font-bold text-xl">
            <TrendingUp size={28} />
            <span>MimicPro</span>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.name}
              onClick={() => setActiveTab(item.name)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                activeTab === item.name
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <item.icon size={20} />
              {item.name}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-200">
          <button className="flex items-center gap-3 px-4 py-3 text-sm font-medium text-slate-500 hover:text-red-600 transition-colors w-full">
            <LogOut size={20} />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="h-16 bg-white border-bottom border-slate-200 shadow-sm flex items-center justify-between px-8 z-10">
          <div className="flex items-center gap-8">
            <div className="relative">
              <label className="flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-0.5">
                Target Location
              </label>
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-700 cursor-pointer">
                <MapPin size={16} className="text-blue-500" />
                <select 
                  value={location} 
                  onChange={(e) => setLocation(e.target.value)}
                  className="bg-transparent border-none focus:ring-0 cursor-pointer appearance-none pr-6"
                >
                  <option value="India">India (IST)</option>
                  <option value="USA">USA (EST)</option>
                </select>
                <ChevronDown size={14} className="absolute right-0 bottom-1" />
              </div>
            </div>

            <div className="h-8 w-px bg-slate-200" />

            <div>
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Remaining Budget</label>
              <div className="text-lg font-bold text-green-600">
                {currencySymbol}{budget.toLocaleString()}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100">
              <Bell size={20} />
            </button>
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
              JD
            </div>
          </div>
        </header>

        {/* Workspace Area */}
        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-6xl mx-auto">
            {/* Page Header */}
            <div className="flex items-end justify-between mb-8">
              <div>
                <h1 className="text-2xl font-bold text-slate-800">Campaign #1: Summer Sale</h1>
                <p className="text-slate-500 mt-1">Configure your keyword bidding strategy for the upcoming summer season.</p>
              </div>
              <div className="flex gap-2">
                <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold uppercase tracking-wide">Draft</span>
                <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-xs font-bold uppercase tracking-wide">Search Network</span>
              </div>
            </div>

            {/* Keyword Table Container */}
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-4 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-700 font-semibold">
                  <Search size={18} />
                  <span>Keyword Selection & Bidding</span>
                </div>
                <div className="text-xs text-slate-400 flex items-center gap-1">
                  <Info size={14} />
                  Estimated clicks are calculated based on Max CPC vs Suggested Bid.
                </div>
              </div>

              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-white text-slate-500 text-[11px] uppercase tracking-wider border-b border-slate-100">
                    <th className="px-6 py-4 font-bold">Keyword</th>
                    <th className="px-6 py-4 font-bold text-center">Monthly Vol.</th>
                    <th className="px-6 py-4 font-bold text-center">Sug. Bid</th>
                    <th className="px-6 py-4 font-bold text-center">Your Max CPC ({currencySymbol})</th>
                    <th className="px-6 py-4 font-bold text-right">Est. Clicks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {keywords.map((kw) => (
                    <tr key={kw.id} className="hover:bg-slate-50 transition-colors group">
                      <td className="px-6 py-4">
                        <div className="font-medium text-slate-800">{kw.keyword}</div>
                        <div className="text-[10px] text-blue-500 font-bold mt-0.5">BROAD MATCH</div>
                      </td>
                      <td className="px-6 py-4 text-center text-slate-600 font-medium">
                        {kw.volume.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className="px-2 py-1 bg-slate-100 rounded text-xs font-mono text-slate-600">
                          {currencySymbol}{kw.suggestedBid}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex justify-center">
                          <input
                            type="number"
                            placeholder="0.00"
                            value={kw.maxCpc || ''}
                            onChange={(e) => handleCpcChange(kw.id, e.target.value)}
                            className="w-24 px-3 py-2 border border-slate-200 rounded-lg text-sm text-center focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all group-hover:border-blue-300"
                          />
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className={`font-bold ${kw.maxCpc > 0 ? 'text-blue-600' : 'text-slate-300'}`}>
                          {calculateEstClicks(kw)}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Bottom Actions */}
              <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
                <p className="text-sm text-slate-500">
                  Total Keywords selected: <span className="font-bold text-slate-700">{keywords.length}</span>
                </p>
                <button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className={`px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold shadow-lg shadow-blue-200 transition-all flex items-center gap-2 transform active:scale-95 ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Processing...
                    </>
                  ) : (
                    'Submit Campaign'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;